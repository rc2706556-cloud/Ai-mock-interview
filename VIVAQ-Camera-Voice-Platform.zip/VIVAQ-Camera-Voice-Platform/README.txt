VIVAQ Camera + Voice Interview Demo

Open index.html in a modern browser, or upload the ZIP to Netlify Drop.
Recommended: deploy to an HTTPS URL, then open it in Chrome and allow camera/microphone permissions.

Features:
- Demo profile and category selection
- Personalised learning cards and quiz
- Camera preview using browser camera permission
- Voice recording with playback
- Browser speech-to-text where supported
- Text answer checklist and basic filler-word estimate

Limitations:
- Demo sign-in is local only; no secure accounts or cloud sync.
- Camera video is preview-only and is not recorded or uploaded.
- Voice recording stays in the page and can be played back; it is not uploaded.
- Speech recognition depends on browser/device support.
- Feedback is simple rule-based, not AI; no emotion, eye-contact or facial analysis.
- Camera/mic normally require HTTPS (Netlify provides HTTPS) and explicit permission.
